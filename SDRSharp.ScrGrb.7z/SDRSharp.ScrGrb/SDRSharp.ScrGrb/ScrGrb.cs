﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SDRSharp.Common;

namespace SDRSharp.ScrGrb
{
    public class ScrGrb : ISharpPlugin
    {
        private const string _displayName = "Tetra grid copy";
        private ISharpControl _control;
        private ScrGrbPanel _guiControl;

        public UserControl Gui
        {
            get { return _guiControl; }
        }

        public string DisplayName
        {
            get { return _displayName; }
        }

        public void Close()
        {
        }

        public void Initialize(ISharpControl control)
        {
            _control = control;
            _guiControl = new ScrGrbPanel();
        }
    }
}
