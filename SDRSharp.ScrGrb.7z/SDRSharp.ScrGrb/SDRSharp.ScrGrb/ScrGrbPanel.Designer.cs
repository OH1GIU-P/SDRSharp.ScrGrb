﻿namespace SDRSharp.ScrGrb
{
    partial class ScrGrbPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelLogFilePath = new System.Windows.Forms.Label();
            this.saveFileDialogNetinfo = new System.Windows.Forms.SaveFileDialog();
            this.buttonLogFile = new System.Windows.Forms.Button();
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.timerTetraLog = new System.Windows.Forms.Timer(this.components);
            this.labelCounter = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelLogFilePath
            // 
            this.labelLogFilePath.AutoSize = true;
            this.labelLogFilePath.Location = new System.Drawing.Point(9, 38);
            this.labelLogFilePath.Name = "labelLogFilePath";
            this.labelLogFilePath.Size = new System.Drawing.Size(35, 13);
            this.labelLogFilePath.TabIndex = 1;
            this.labelLogFilePath.Text = "label1";
            // 
            // saveFileDialogNetinfo
            // 
            this.saveFileDialogNetinfo.DefaultExt = "txt";
            this.saveFileDialogNetinfo.OverwritePrompt = false;
            this.saveFileDialogNetinfo.RestoreDirectory = true;
            this.saveFileDialogNetinfo.Title = "Netinfo grid log file";
            // 
            // buttonLogFile
            // 
            this.buttonLogFile.Location = new System.Drawing.Point(10, 6);
            this.buttonLogFile.Name = "buttonLogFile";
            this.buttonLogFile.Size = new System.Drawing.Size(100, 23);
            this.buttonLogFile.TabIndex = 2;
            this.buttonLogFile.Text = "Log file path  ...";
            this.buttonLogFile.UseVisualStyleBackColor = true;
            this.buttonLogFile.Click += new System.EventHandler(this.buttonLogFile_Click);
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(12, 64);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(75, 23);
            this.buttonStart.TabIndex = 3;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Location = new System.Drawing.Point(103, 64);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(75, 23);
            this.buttonStop.TabIndex = 4;
            this.buttonStop.Text = "Stop";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // timerTetraLog
            // 
            this.timerTetraLog.Interval = 6000;
            this.timerTetraLog.Tick += new System.EventHandler(this.timerTetraLog_Tick);
            // 
            // labelCounter
            // 
            this.labelCounter.AutoSize = true;
            this.labelCounter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCounter.Location = new System.Drawing.Point(12, 98);
            this.labelCounter.Name = "labelCounter";
            this.labelCounter.Size = new System.Drawing.Size(13, 13);
            this.labelCounter.TabIndex = 5;
            this.labelCounter.Text = "0";
            // 
            // ScrGrbPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.labelCounter);
            this.Controls.Add(this.buttonStop);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.buttonLogFile);
            this.Controls.Add(this.labelLogFilePath);
            this.Name = "ScrGrbPanel";
            this.Size = new System.Drawing.Size(208, 152);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelLogFilePath;
        private System.Windows.Forms.SaveFileDialog saveFileDialogNetinfo;
        private System.Windows.Forms.Button buttonLogFile;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Timer timerTetraLog;
        private System.Windows.Forms.Label labelCounter;
    }
}
