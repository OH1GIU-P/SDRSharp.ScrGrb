﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;

namespace SDRSharp.ScrGrb
{
    public partial class ScrGrbPanel : UserControl
    {
        [DllImport("user32.dll")]
        static extern void SwitchToThisWindow(IntPtr hWnd, bool turnOn);
        [DllImport("user32.dll")]
        static extern IntPtr FindWindow(StringBuilder lpClassName, StringBuilder lpWindowName);

        const bool DEBUG = false;
        const string NETINFO_ERR = "Cannot find Network Info window";
        const string PLUGIN_TITLE = "Tetra grid copy";

        StreamWriter tetraLog = null;
        IntPtr hwnd = IntPtr.Zero;
        int counter = 0;
        StringBuilder name = new StringBuilder("Network Info");

        public ScrGrbPanel()
        {
            InitializeComponent();
            labelLogFilePath.Text = "";
            buttonStop.Enabled = false;
            if (DEBUG)
            {
                labelLogFilePath.Text = @"C:\Temp\tetra.txt";
            }
        }

        private void buttonLogFile_Click(object sender, EventArgs e)
        {
            if (saveFileDialogNetinfo.ShowDialog() == DialogResult.OK)
            {
                labelLogFilePath.Text =  saveFileDialogNetinfo.FileName;
            }
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            closeLog();
            timerTetraLog.Enabled = false;
            buttonStop.Enabled = false;
            buttonStart.Enabled = true;
            buttonLogFile.Enabled = true;
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            hwnd = IntPtr.Zero;
            hwnd = FindWindow(null, name);
            if (hwnd == IntPtr.Zero)
            {
                MessageBox.Show(NETINFO_ERR, PLUGIN_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            closeLog();
            try
            {
                tetraLog = new StreamWriter(labelLogFilePath.Text, true);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, PLUGIN_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            labelCounter.Text = "0";
            counter = 0;
            buttonStart.Enabled = false;
            buttonStop.Enabled = true;
            buttonLogFile.Enabled = false;
            timerTetraLog.Enabled = true;
        }

        private void timerTetraLog_Tick(object sender, EventArgs e)
        {
            SwitchToThisWindow(hwnd, true);
            SendKeys.SendWait("^a");
            SendKeys.SendWait("^c");
            tetraLog.WriteLine("\r\n" + DateTime.Now.ToString("yyyyMMddHHmmss") + " *************\r\n" + Clipboard.GetText());
            counter++;
            labelCounter.Text = counter.ToString();
        }

        private void closeLog()
        {
            if (tetraLog != null)
            {
                tetraLog.Flush();
                tetraLog.Close();
                tetraLog.Dispose();
                tetraLog = null;
            }
        }
    }
}
